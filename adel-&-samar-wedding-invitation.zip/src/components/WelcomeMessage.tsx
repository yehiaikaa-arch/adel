import React from 'react';
import { GoldFlourishDivider } from './Ornaments';
import { Heart, Stars } from 'lucide-react';

export const WelcomeMessage: React.FC = () => {
  return (
    <section id="welcome" className="py-12 sm:py-16 px-4 bg-[#FAF8F5] relative">
      <div className="max-w-3xl mx-auto text-center">
        {/* Soft Kicker */}
        <div className="inline-flex items-center gap-2 text-xs font-serif tracking-widest text-[#996515] uppercase mb-3">
          <Stars className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>أهلاً وسهلاً بضيوفنا الكرام</span>
          <Stars className="w-3.5 h-3.5 text-[#D4AF37]" />
        </div>

        <h2 className="text-2xl sm:text-3xl md:text-4xl font-amiri font-bold text-[#1A1816] mb-4">
          فرحتنا لا تكتمل إلا بوجودكم
        </h2>

        <GoldFlourishDivider />

        <div className="mt-6 bg-white/70 border border-[#E8DFC8] rounded-2xl p-6 sm:p-8 backdrop-blur-xs shadow-xs relative">
          <p className="font-amiri text-lg sm:text-xl text-[#3C3630] leading-relaxed mb-4">
            بقلوب يملؤها الفرح والمحبة، وبفيض من مشاعر السعادة والامتنان، يتشرف
            <strong className="text-[#996515] mx-1.5 font-bold">عادل و سمر</strong>
            بدعوتكم لمشاركتنا فرحة عقد القران وبداية رحلة العمر معاً.
          </p>
          <p className="font-alexandria text-sm sm:text-base text-[#766E65] leading-relaxed max-w-xl mx-auto">
            حضوركم ينير ليلتنا، ودعواتكم الطيبة تبارك خطانا نحو مستقبل مشرق ملؤه المودة والسكينة.
          </p>

          <div className="mt-6 pt-5 border-t border-[#F0E8D8] flex items-center justify-center gap-2 text-[#996515] text-xs font-serif">
            <Heart className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
            <span className="font-garamond italic text-base">Adel & Samar</span>
            <span className="text-[#B38F3F]">·</span>
            <span className="font-amiri text-sm">عادل وسمر</span>
          </div>
        </div>
      </div>
    </section>
  );
};
