import React, { useState, useEffect } from 'react';
import { Calendar, Clock, CalendarPlus, ExternalLink, Sparkles } from 'lucide-react';
import { GoldFlourishDivider } from './Ornaments';
import { WEDDING_DATA } from '../types/wedding';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
}

export const CountdownSection: React.FC = () => {
  // Official confirmed wedding date: 23/10/2026 at 8:30 PM (20:30)
  const [targetDate] = useState<string>(WEDDING_DATA.date.iso); // 2026-10-23
  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(null);

  useEffect(() => {
    const calculateTime = () => {
      // 8:30 PM on 2026-10-23
      const targetTime = new Date(`${targetDate}T20:30:00`).getTime();
      const now = new Date().getTime();
      const difference = targetTime - now;

      if (difference <= 0) {
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
          isPast: true,
        });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({
        days,
        hours,
        minutes,
        seconds,
        isPast: false,
      });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  const handleDownloadIcs = () => {
    // 2026-10-23 20:30 to 23:30 (approx Egypt UTC+2 or UTC+3, standard UTC representation 173000Z)
    const startDate = '20261023T183000Z';
    const endDate = '20261023T213000Z';
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Adel & Samar Wedding//AR',
      'BEGIN:VEVENT',
      `SUMMARY:حفل زفاف عادل وسمر | Adel & Samar Wedding`,
      `DESCRIPTION:نتشرف بحضوركم حفل زفاف وعقد قران عادل وسمر في مسجد المشير طنطاوي - قاعة الروضة الساعة 8:30 مساءً. هاتف: 01205242682`,
      `LOCATION:مسجد المشير طنطاوي، قاعة الروضة، محور المشير طنطاوي، الحي العاشر، مدينة نصر، القاهرة`,
      `DTSTART:${startDate}`,
      `DTEND:${endDate}`,
      'STATUS:CONFIRMED',
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Adel-Samar-Wedding-23Oct2026.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(
    'حفل زفاف عادل وسمر | Adel & Samar Wedding'
  )}&dates=20261023T183000Z/20261023T213000Z&details=${encodeURIComponent(
    'حفل زفاف وعقد قران عادل وسمر في مسجد المشير طنطاوي - قاعة الروضة في تمام الساعة 8:30 مساءً. هاتف: 01205242682'
  )}&location=${encodeURIComponent(
    'مسجد المشير طنطاوي، قاعة الروضة، القاهرة'
  )}`;

  return (
    <section id="countdown" className="py-14 sm:py-20 px-4 bg-[#FAF8F5] relative">
      <div className="max-w-4xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <p className="text-xs uppercase tracking-widest text-[#996515] font-serif font-medium mb-2">
            Wedding Countdown · العد التنازلي للحفل
          </p>
          <h2 className="text-3xl sm:text-4xl font-amiri font-bold text-[#1A1816]">
            نعد الأيام واللحظات للقائكم
          </h2>
          <GoldFlourishDivider />
          <p className="text-sm text-[#766E65] font-alexandria mt-2">
            كل ثانية تقربنا من مشاركتكم أجمل وأسعد لحظات العمر
          </p>
        </div>

        {/* Countdown Box */}
        <div className="bg-white border border-[#E8DFC8] rounded-3xl p-6 sm:p-10 shadow-md relative overflow-hidden">
          {/* Confirmed Date Badge */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full bg-[#FAF5E8] border border-[#D4AF37]/50 text-[#996515] text-xs sm:text-sm font-medium shadow-2xs">
              <Calendar className="w-4 h-4 text-[#D4AF37]" />
              <span className="font-bold text-[#1A1816]">
                {WEDDING_DATA.date.ar} ({WEDDING_DATA.date.formatted})
              </span>
              <span>·</span>
              <span className="flex items-center gap-1 text-[#996515]">
                <Clock className="w-3.5 h-3.5" />
                <span>{WEDDING_DATA.time.ar}</span>
              </span>
            </div>
            <p className="text-xs text-[#766E65] mt-2 font-serif">
              مسجد المشير طنطاوي · قاعة الروضة
            </p>
          </div>

          {/* Ticking Numbers Grid */}
          {timeLeft && (
            <div>
              {timeLeft.isPast ? (
                <div className="text-center py-6">
                  <p className="text-2xl font-amiri font-bold text-[#996515]">
                    بارك الله للعروسين عادل وسمر وجمع بينهما في خير! 🎉
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 max-w-2xl mx-auto my-6">
                  {/* Days */}
                  <div className="bg-[#FAF8F5] border border-[#E8DFC8] rounded-2xl p-4 sm:p-6 text-center shadow-xs">
                    <span className="text-3xl sm:text-5xl font-mono font-bold text-[#1A1816] tabular-nums block">
                      {timeLeft.days}
                    </span>
                    <span className="text-xs font-serif uppercase tracking-wider text-[#996515] mt-1.5 block">
                      يوم · Days
                    </span>
                  </div>

                  {/* Hours */}
                  <div className="bg-[#FAF8F5] border border-[#E8DFC8] rounded-2xl p-4 sm:p-6 text-center shadow-xs">
                    <span className="text-3xl sm:text-5xl font-mono font-bold text-[#1A1816] tabular-nums block">
                      {String(timeLeft.hours).padStart(2, '0')}
                    </span>
                    <span className="text-xs font-serif uppercase tracking-wider text-[#996515] mt-1.5 block">
                      ساعة · Hours
                    </span>
                  </div>

                  {/* Minutes */}
                  <div className="bg-[#FAF8F5] border border-[#E8DFC8] rounded-2xl p-4 sm:p-6 text-center shadow-xs">
                    <span className="text-3xl sm:text-5xl font-mono font-bold text-[#1A1816] tabular-nums block">
                      {String(timeLeft.minutes).padStart(2, '0')}
                    </span>
                    <span className="text-xs font-serif uppercase tracking-wider text-[#996515] mt-1.5 block">
                      دقيقة · Minutes
                    </span>
                  </div>

                  {/* Seconds */}
                  <div className="bg-[#FAF8F5] border border-[#E8DFC8] rounded-2xl p-4 sm:p-6 text-center shadow-xs">
                    <span className="text-3xl sm:text-5xl font-mono font-bold text-[#996515] tabular-nums block animate-pulse">
                      {String(timeLeft.seconds).padStart(2, '0')}
                    </span>
                    <span className="text-xs font-serif uppercase tracking-wider text-[#996515] mt-1.5 block">
                      ثانية · Seconds
                    </span>
                  </div>
                </div>
              )}

              {/* Add to Calendar Action Strip */}
              <div className="mt-8 pt-6 border-t border-[#F0E8D8] flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={handleDownloadIcs}
                  className="px-5 py-3 rounded-full bg-[#1A1816] text-[#FAF8F5] text-xs sm:text-sm font-medium hover:bg-[#996515] transition-colors flex items-center gap-2 shadow-xs cursor-pointer active:scale-98"
                >
                  <CalendarPlus className="w-4 h-4 text-[#E8C15A]" />
                  <span>حفظ الموعد في التقويم (.ics)</span>
                </button>

                <a
                  href={googleCalendarUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3 rounded-full border border-[#E8DFC8] bg-white text-[#766E65] text-xs sm:text-sm font-medium hover:text-[#2C2723] hover:border-[#C5A059] transition-colors flex items-center gap-2"
                >
                  <span>Google Calendar</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
