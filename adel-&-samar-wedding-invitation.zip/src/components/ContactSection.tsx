import React, { useState } from 'react';
import { Phone, MessageCircle, Copy, Check, Headphones } from 'lucide-react';
import { GoldFlourishDivider } from './Ornaments';
import { WEDDING_DATA } from '../types/wedding';

export const ContactSection: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(WEDDING_DATA.contact.phone);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const whatsappMessage = encodeURIComponent(
    'السلام عليكم، ألف مبروك للعروسين عادل وسمر! بخصوص حفل الزفاف في مسجد المشير طنطاوي..'
  );
  const whatsappUrl = `https://wa.me/${WEDDING_DATA.contact.whatsappNumber}?text=${whatsappMessage}`;

  return (
    <section id="contact" className="py-14 sm:py-20 px-4 bg-[#F7F3EB]/60 border-t border-[#E8DFC8]/60 relative">
      <div className="max-w-4xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <p className="text-xs uppercase tracking-widest text-[#996515] font-serif font-medium mb-2">
            Direct Contact · التواصل والاستفسارات
          </p>
          <h2 className="text-3xl sm:text-4xl font-amiri font-bold text-[#1A1816]">
            يسعدنا تواصلكم واستفساراتكم
          </h2>
          <GoldFlourishDivider />
          <p className="text-sm text-[#766E65] font-alexandria mt-2">
            لأي استفسار بخصوص الحضور أو الوصول أو التنسيق، نحن دائماً في خدمتكم
          </p>
        </div>

        {/* Contact Banner Card */}
        <div className="bg-white border border-[#E8DFC8] rounded-3xl p-6 sm:p-10 shadow-md text-center max-w-2xl mx-auto relative overflow-hidden">
          <div className="w-16 h-16 mx-auto rounded-full bg-[#FAF5E8] border border-[#E8DFC8] flex items-center justify-center text-[#996515] mb-4">
            <Headphones className="w-7 h-7 text-[#996515]" />
          </div>

          <p className="text-xs font-serif uppercase tracking-widest text-[#766E65] mb-2">
            رقم التواصل المباشر
          </p>

          {/* Formatted Phone Number */}
          <div className="py-2">
            <a
              href={`tel:${WEDDING_DATA.contact.phone}`}
              className="text-3xl sm:text-4xl font-bold font-mono tracking-wider text-[#1A1816] hover:text-[#996515] transition-colors inline-block"
              dir="ltr"
            >
              {WEDDING_DATA.contact.displayPhone}
            </a>
          </div>

          <p className="text-xs text-[#766E65] max-w-md mx-auto mt-2 mb-6">
            متاح للاتصال المباشر والمراسلة عبر تطبيق واتساب على مدار اليوم
          </p>

          {/* Direct Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            {/* Direct Call Button */}
            <a
              href={`tel:${WEDDING_DATA.contact.phone}`}
              className="w-full sm:w-auto px-7 py-3.5 rounded-full bg-[#1A1816] text-[#FAF8F5] text-sm font-medium hover:bg-[#996515] transition-all flex items-center justify-center gap-2 shadow-sm"
            >
              <Phone className="w-4 h-4 text-[#E8C15A]" />
              <span>اتصال هاتفي مباشر</span>
            </a>

            {/* Direct WhatsApp Button */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-[#25D366] text-white text-sm font-medium hover:bg-[#20ba59] transition-all flex items-center justify-center gap-2 shadow-sm"
            >
              <MessageCircle className="w-4 h-4" />
              <span>محادثة واتساب</span>
            </a>

            {/* Copy Button */}
            <button
              type="button"
              onClick={handleCopyPhone}
              className="w-full sm:w-auto px-5 py-3.5 rounded-full border border-[#E8DFC8] bg-white text-[#766E65] text-sm font-medium hover:text-[#2C2723] hover:border-[#C5A059] transition-all flex items-center justify-center gap-2"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700 text-xs">تم النسخ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-[#C5A059]" />
                  <span className="text-xs">نسخ الرقم</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
