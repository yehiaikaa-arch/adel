import React from 'react';
import { Calendar, Clock, MapPin, Building, Sparkles } from 'lucide-react';
import { GoldFlourishDivider } from './Ornaments';
import { WEDDING_DATA } from '../types/wedding';

interface EventDetailsProps {
  onOpenMap: () => void;
}

export const EventDetails: React.FC<EventDetailsProps> = ({ onOpenMap }) => {
  return (
    <section id="details" className="py-14 sm:py-20 px-4 bg-[#F7F3EB]/60 border-y border-[#E8DFC8]/60 relative">
      <div className="max-w-5xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-xs uppercase tracking-widest text-[#996515] font-serif font-medium mb-2">
            Event Information · تفاصيل المناسبة
          </p>
          <h2 className="text-3xl sm:text-4xl font-amiri font-bold text-[#1A1816]">
            موعد ومكان الحفل
          </h2>
          <GoldFlourishDivider />
          <p className="text-sm text-[#766E65] font-alexandria mt-2">
            يسعدنا استقبالكم في الموعد المحدد لمشاركتنا هذه اللحظة الاستثنائية
          </p>
        </div>

        {/* 4 Grid Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Card 1: Date */}
          <div className="bg-white border-2 border-[#D4AF37]/50 rounded-2xl p-6 text-center shadow-xs hover:border-[#D4AF37] transition-all relative overflow-hidden group">
            <div className="w-12 h-12 mx-auto rounded-full bg-[#FAF5E8] border border-[#E8DFC8] flex items-center justify-center text-[#996515] mb-4 group-hover:scale-110 transition-transform">
              <Calendar className="w-6 h-6 text-[#996515]" />
            </div>

            <span className="text-xs font-serif tracking-wider text-[#996515] uppercase block mb-1">
              تاريخ الحفل
            </span>
            <h3 className="text-xl sm:text-2xl font-amiri font-bold text-[#1A1816] mb-1">
              {WEDDING_DATA.date.dayNameAr}
            </h3>
            <p className="text-base font-semibold text-[#996515] mb-2 font-mono">
              {WEDDING_DATA.date.formatted}
            </p>
            <p className="text-xs text-[#766E65] leading-relaxed border-t border-[#F4EFE6] pt-3">
              {WEDDING_DATA.date.ar}
            </p>
          </div>

          {/* Card 2: Time */}
          <div className="bg-white border border-[#E8DFC8] rounded-2xl p-6 text-center shadow-xs hover:border-[#D4AF37] transition-all relative overflow-hidden group">
            <div className="w-12 h-12 mx-auto rounded-full bg-[#FAF5E8] border border-[#E8DFC8] flex items-center justify-center text-[#996515] mb-4 group-hover:scale-110 transition-transform">
              <Clock className="w-6 h-6 text-[#996515]" />
            </div>

            <span className="text-xs font-serif tracking-wider text-[#996515] uppercase block mb-1">
              التوقيت الميمون
            </span>
            <h3 className="text-xl sm:text-2xl font-amiri font-bold text-[#1A1816] mb-1">
              {WEDDING_DATA.time.ar}
            </h3>
            <p className="text-sm font-garamond italic text-[#766E65] mb-2">
              {WEDDING_DATA.time.en}
            </p>
            <p className="text-xs text-[#766E65] leading-relaxed border-t border-[#F4EFE6] pt-3">
              يبدأ استقبال الضيوف الكرام وعقد القران في تمام 8:30 مساءً
            </p>
          </div>

          {/* Card 3: Mosque & Venue */}
          <div className="bg-white border border-[#E8DFC8] rounded-2xl p-6 text-center shadow-xs hover:border-[#D4AF37] transition-all relative overflow-hidden group">
            <div className="w-12 h-12 mx-auto rounded-full bg-[#FAF5E8] border border-[#E8DFC8] flex items-center justify-center text-[#996515] mb-4 group-hover:scale-110 transition-transform">
              <Building className="w-6 h-6 text-[#996515]" />
            </div>

            <span className="text-xs font-serif tracking-wider text-[#996515] uppercase block mb-1">
              المكان
            </span>
            <h3 className="text-xl sm:text-2xl font-amiri font-bold text-[#1A1816] mb-1">
              {WEDDING_DATA.venue.nameAr}
            </h3>
            <p className="text-xs font-serif text-[#766E65] mb-2 truncate">
              {WEDDING_DATA.venue.nameEn}
            </p>
            <p className="text-xs text-[#766E65] leading-relaxed border-t border-[#F4EFE6] pt-3">
              محور المشير طنطاوي – الحي العاشر – التجمع
            </p>
          </div>

          {/* Card 4: Hall */}
          <div className="bg-white border border-[#E8DFC8] rounded-2xl p-6 text-center shadow-xs hover:border-[#D4AF37] transition-all relative overflow-hidden group">
            <div className="w-12 h-12 mx-auto rounded-full bg-[#FAF5E8] border border-[#E8DFC8] flex items-center justify-center text-[#996515] mb-4 group-hover:scale-110 transition-transform">
              <Sparkles className="w-6 h-6 text-[#996515]" />
            </div>

            <span className="text-xs font-serif tracking-wider text-[#996515] uppercase block mb-1">
              القاعة المخصصة
            </span>
            <h3 className="text-xl sm:text-2xl font-amiri font-bold text-[#1A1816] mb-1">
              {WEDDING_DATA.venue.hallAr}
            </h3>
            <p className="text-xs font-serif text-[#766E65] mb-2">
              {WEDDING_DATA.venue.hallEn}
            </p>
            <p className="text-xs text-[#766E65] leading-relaxed border-t border-[#F4EFE6] pt-3">
              قاعة فخمة ومكيفة ومجهزة بالكامل لاستقبال الضيوف
            </p>
          </div>
        </div>

        {/* Quick Location Action Strip */}
        <div className="mt-10 bg-white border border-[#E8DFC8] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xs">
          <div className="flex items-start gap-4 text-right">
            <div className="w-10 h-10 rounded-full bg-[#FAF5E8] border border-[#E8DFC8] flex items-center justify-center shrink-0 text-[#996515] mt-1">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-semibold text-[#1A1816] font-alexandria">
                مسجد المشير طنطاوي · قاعة الروضة
              </h4>
              <p className="text-xs text-[#766E65] mt-1 leading-relaxed">
                العنوان: محور المشير طنطاوي، الحي العاشر، مدينة نصر، محافظة القاهرة (بالقرب من مدخل التجمع الخامس)
              </p>
              <p className="text-[11px] text-[#996515] font-mono mt-1">
                رمز بلس: {WEDDING_DATA.venue.plusCode}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 w-full sm:w-auto">
            <button
              type="button"
              onClick={onOpenMap}
              className="w-full sm:w-auto px-6 py-3 rounded-full bg-[#1A1816] text-[#FAF8F5] text-xs sm:text-sm font-medium hover:bg-[#996515] transition-colors flex items-center justify-center gap-2 whitespace-nowrap shadow-xs"
            >
              <MapPin className="w-4 h-4 text-[#E8C15A]" />
              <span>عرض الخريطة والاتجاهات</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
