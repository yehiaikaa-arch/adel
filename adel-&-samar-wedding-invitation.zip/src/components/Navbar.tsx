import React, { useState } from 'react';
import { Volume2, VolumeX, Phone, Heart } from 'lucide-react';
import { weddingAudio } from '../utils/audio';
import { WEDDING_DATA } from '../types/wedding';

interface NavbarProps {
  onRsvpClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onRsvpClick }) => {
  const [isPlaying, setIsPlaying] = useState(false);

  const handleAudioToggle = () => {
    const state = weddingAudio.toggle((playing) => setIsPlaying(playing));
    setIsPlaying(state);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/90 backdrop-blur-md border-b border-[#E8DFC8]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element Brand Zone */}
        <a
          href="#top"
          className="text-xl sm:text-2xl font-serif tracking-wide text-[#2C2723] hover:text-[#996515] transition-colors whitespace-nowrap shrink-0 flex items-center gap-2 font-semibold"
        >
          <span className="font-garamond italic">Adel & Samar</span>
          <span className="text-[#C5A059] text-xs font-normal font-amiri hidden xs:inline">· عادل وسمر</span>
        </a>

        {/* Zone 2: 4-5 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#766E65]">
          <a href="#welcome" className="hover:text-[#996515] transition-colors whitespace-nowrap">
            الترحيب
          </a>
          <a href="#details" className="hover:text-[#996515] transition-colors whitespace-nowrap">
            المكان والموعد
          </a>
          <a href="#location" className="hover:text-[#996515] transition-colors whitespace-nowrap">
            الخريطة
          </a>
          <a href="#countdown" className="hover:text-[#996515] transition-colors whitespace-nowrap">
            العد التنازلي
          </a>
          <a href="#rsvp" className="hover:text-[#996515] transition-colors whitespace-nowrap">
            تأكيد الحضور
          </a>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Ambient Music Toggle */}
          <button
            type="button"
            onClick={handleAudioToggle}
            className={`p-2 rounded-full border transition-all flex items-center justify-center ${
              isPlaying
                ? 'bg-[#F4ECE1] border-[#C5A059] text-[#996515] shadow-xs'
                : 'bg-white border-[#E8DFC8] text-[#766E65] hover:text-[#2C2723]'
            }`}
            title={isPlaying ? "إيقاف الموسيقى الهادئة" : "تشغيل موسيقى هادئة"}
            aria-label={isPlaying ? "Mute ambient harp" : "Play ambient harp"}
          >
            {isPlaying ? (
              <span className="flex items-center gap-1.5 px-1">
                <Volume2 className="w-4 h-4 animate-pulse text-[#C5A059]" />
                <span className="text-xs font-medium hidden sm:inline text-[#996515]">موسيقى</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 px-1">
                <VolumeX className="w-4 h-4" />
                <span className="text-xs font-medium hidden sm:inline">تشغيل النغم</span>
              </span>
            )}
          </button>

          {/* Direct Call Quick Action */}
          <a
            href={`tel:${WEDDING_DATA.contact.phone}`}
            className="p-2 sm:px-3 sm:py-2 rounded-full border border-[#E8DFC8] bg-white text-[#766E65] hover:text-[#2C2723] hover:border-[#C5A059] transition-all flex items-center gap-1.5 text-xs font-medium"
            title="اتصال مباشر"
          >
            <Phone className="w-3.5 h-3.5 text-[#C5A059]" />
            <span className="hidden lg:inline">{WEDDING_DATA.contact.displayPhone}</span>
          </a>

          {/* Primary RSVP CTA */}
          <button
            type="button"
            onClick={onRsvpClick}
            className="px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-full bg-[#1A1816] text-[#FAF8F5] text-xs sm:text-sm font-medium hover:bg-[#996515] transition-colors whitespace-nowrap shadow-xs flex items-center gap-1.5"
          >
            <Heart className="w-3.5 h-3.5 text-[#E8C15A] fill-[#E8C15A]" />
            <span>تأكيد الحضور</span>
          </button>
        </div>
      </div>
    </header>
  );
};
