import React from 'react';

export const GoldCrest: React.FC<{ size?: number; className?: string }> = ({ size = 96, className = "" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`inline-block ${className}`}
    aria-label="Adel & Samar Monogram Crest"
  >
    <defs>
      <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#996515" />
        <stop offset="35%" stopColor="#D4AF37" />
        <stop offset="55%" stopColor="#F3E5AB" />
        <stop offset="75%" stopColor="#D4AF37" />
        <stop offset="100%" stopColor="#8A6414" />
      </linearGradient>
      <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="2" result="blur" />
        <feComposite in="SourceGraphic" in2="blur" operator="over" />
      </filter>
    </defs>

    {/* Outer Dotted Filigree Ring */}
    <circle cx="60" cy="60" r="54" stroke="url(#goldGrad)" strokeWidth="1" strokeDasharray="3 4" opacity="0.6" />
    
    {/* Inner Solid Laurel Ring */}
    <circle cx="60" cy="60" r="48" stroke="url(#goldGrad)" strokeWidth="1.5" />
    
    {/* Laurel Leaves (Left Branch) */}
    <path
      d="M34 68C32 60 34 50 40 42C41 45 42 50 40 55M31 52C28 47 30 40 36 36C36 40 37 44 34 48M39 36C36 30 40 24 47 22C46 26 45 30 41 33M50 24C49 19 55 15 60 16C58 20 56 23 52 24"
      stroke="url(#goldGrad)"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    
    {/* Laurel Leaves (Right Branch) */}
    <path
      d="M86 68C88 60 86 50 80 42C79 45 78 50 80 55M89 52C92 47 90 40 84 36C84 40 83 44 86 48M81 36C84 30 80 24 73 22C74 26 75 30 79 33M70 24C71 19 65 15 60 16C62 20 64 23 68 24"
      stroke="url(#goldGrad)"
      strokeWidth="1.5"
      strokeLinecap="round"
    />

    {/* Monogram A & S */}
    <text
      x="50"
      y="66"
      textAnchor="middle"
      fontFamily="'Cormorant Garamond', 'Great Vibes', serif"
      fontSize="24"
      fontWeight="600"
      fill="url(#goldGrad)"
      fontStyle="italic"
    >
      A
    </text>
    <text
      x="60"
      y="67"
      textAnchor="middle"
      fontFamily="'Cormorant Garamond', serif"
      fontSize="14"
      fill="url(#goldGrad)"
      opacity="0.8"
    >
      &
    </text>
    <text
      x="71"
      y="66"
      textAnchor="middle"
      fontFamily="'Cormorant Garamond', 'Great Vibes', serif"
      fontSize="24"
      fontWeight="600"
      fill="url(#goldGrad)"
      fontStyle="italic"
    >
      S
    </text>

    {/* Small bottom crown / ribbon knot */}
    <circle cx="60" cy="88" r="2.5" fill="url(#goldGrad)" />
    <path d="M54 90C57 88 60 89 60 89C60 89 63 88 66 90" stroke="url(#goldGrad)" strokeWidth="1" strokeLinecap="round" />
  </svg>
);

export const GoldFlourishDivider: React.FC<{ className?: string }> = ({ className = "" }) => (
  <div className={`flex items-center justify-center gap-3 my-4 ${className}`} aria-hidden="true">
    <div className="h-[1px] w-12 sm:w-20 bg-gradient-to-r from-transparent via-[#D4AF37] to-[#D4AF37]/60" />
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-[#D4AF37] shrink-0">
      <path
        d="M12 2L13.8 8.2L20 10L13.8 11.8L12 18L10.2 11.8L4 10L10.2 8.2L12 2Z"
        fill="#D4AF37"
        opacity="0.9"
      />
      <circle cx="12" cy="10" r="1.5" fill="#FAF8F5" />
    </svg>
    <div className="h-[1px] w-12 sm:w-20 bg-gradient-to-l from-transparent via-[#D4AF37] to-[#D4AF37]/60" />
  </div>
);

export const CornerFlourish: React.FC<{ position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'; className?: string }> = ({ position, className = "" }) => {
  const rotation = {
    'top-left': '',
    'top-right': 'scale-x-[-1]',
    'bottom-left': 'scale-y-[-1]',
    'bottom-right': 'rotate-180',
  }[position];

  return (
    <svg
      width="48"
      height="48"
      viewBox="0 0 48 48"
      fill="none"
      className={`text-[#D4AF37] opacity-60 ${rotation} ${className}`}
      aria-hidden="true"
    >
      <path
        d="M4 44V12C4 7.58172 7.58172 4 12 4H44"
        stroke="#D4AF37"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M10 36V16C10 12.6863 12.6863 10 16 10H36"
        stroke="#D4AF37"
        strokeWidth="0.75"
        strokeDasharray="2 2"
        strokeLinecap="round"
      />
      <circle cx="12" cy="12" r="2.5" fill="#D4AF37" />
    </svg>
  );
};
