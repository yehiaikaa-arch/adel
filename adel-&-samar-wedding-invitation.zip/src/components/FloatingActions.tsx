import React from 'react';
import { MapPin, Phone, Heart } from 'lucide-react';
import { WEDDING_DATA } from '../types/wedding';

interface FloatingActionsProps {
  onRsvpClick: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({ onRsvpClick }) => {
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    WEDDING_DATA.venue.googleMapsQuery
  )}`;

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-t border-[#E8DFC8] px-3 py-2.5 shadow-lg">
      <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
        {/* Maps Button */}
        <a
          href={googleMapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2.5 px-2 rounded-xl bg-white border border-[#E8DFC8] text-[#1A1816] text-xs font-medium hover:border-[#D4AF37] transition-all flex items-center justify-center gap-1.5 shadow-2xs"
        >
          <MapPin className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>الخريطة</span>
        </a>

        {/* Direct Call Button */}
        <a
          href={`tel:${WEDDING_DATA.contact.phone}`}
          className="flex-1 py-2.5 px-2 rounded-xl bg-white border border-[#E8DFC8] text-[#1A1816] text-xs font-medium hover:border-[#D4AF37] transition-all flex items-center justify-center gap-1.5 shadow-2xs"
        >
          <Phone className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>اتصال</span>
        </a>

        {/* Primary RSVP Button */}
        <button
          type="button"
          onClick={onRsvpClick}
          className="flex-1 py-2.5 px-2 rounded-xl bg-[#1A1816] text-[#FAF8F5] text-xs font-medium hover:bg-[#996515] transition-all flex items-center justify-center gap-1.5 shadow-xs"
        >
          <Heart className="w-3.5 h-3.5 text-[#E8C15A] fill-[#E8C15A]" />
          <span>تأكيد الحضور</span>
        </button>
      </div>
    </div>
  );
};
