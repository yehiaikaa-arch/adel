import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Heart, Send, CheckCircle2, MessageSquare, MessageCircle, User, Users, Sparkles } from 'lucide-react';
import { GoldFlourishDivider } from './Ornaments';
import { GuestBlessing, WEDDING_DATA } from '../types/wedding';

const INITIAL_BLESSINGS: GuestBlessing[] = [
  {
    id: 'b1',
    name: 'د. طارق وسامية',
    relation: 'الأهل والأصدقاء',
    message: 'بارك الله لكما وبارك عليكما وجمع بينكما في خير ومودة وسعادة أبدية يا عادل ويا سمر.',
    createdAt: 'منذ يومين',
    attending: true,
    companionsCount: 2,
  },
  {
    id: 'b2',
    name: 'م. أحمد خالد',
    relation: 'صديق العريس',
    message: 'ألف مليون مبروك لأخويا وحبيبي عادل وأجمل عروسة سمر، ربنا يتمم لكم على خير ويسعد أيامكم.',
    createdAt: 'منذ يوم',
    attending: true,
    companionsCount: 1,
  },
  {
    id: 'b3',
    name: 'مروة الشريف',
    relation: 'صديقة العروس',
    message: 'أجمل عروسين في الدنيا! ربي يجعل أيامكم كلها فرح وهنا وسرور ويوفقكم في حياتكم الجديدة.',
    createdAt: 'اليوم',
    attending: true,
    companionsCount: 2,
  },
];

export const RsvpSection: React.FC = () => {
  const [name, setName] = useState('');
  const [relation, setRelation] = useState('');
  const [attending, setAttending] = useState<boolean>(true);
  const [companions, setCompanions] = useState<number>(1);
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [blessings, setBlessings] = useState<GuestBlessing[]>([]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('adel_samar_blessings');
      if (stored) {
        setBlessings(JSON.parse(stored));
      } else {
        setBlessings(INITIAL_BLESSINGS);
        localStorage.setItem('adel_samar_blessings', JSON.stringify(INITIAL_BLESSINGS));
      }
    } catch {
      setBlessings(INITIAL_BLESSINGS);
    }
  }, []);

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#D4AF37', '#996515', '#FAF5E8', '#F3E5AB'],
      });
    } catch {
      // Fallback
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newBlessing: GuestBlessing = {
      id: Date.now().toString(),
      name: name.trim(),
      relation: relation.trim() || (attending ? 'ضيف كريم' : 'محب ومهنئ'),
      message: message.trim() || (attending ? 'يشرفني الحضور بكل سرور، ألف مبروك للعروسين!' : 'معتذر لظروف خاصة، وأتمنى لكما زواجاً مباركاً ملؤه السعادة.'),
      createdAt: 'الآن',
      attending,
      companionsCount: companions,
    };

    const updated = [newBlessing, ...blessings];
    setBlessings(updated);
    try {
      localStorage.setItem('adel_samar_blessings', JSON.stringify(updated));
    } catch {
      // Ignore
    }

    setIsSubmitted(true);
    triggerConfetti();
  };

  const handleSendViaWhatsApp = () => {
    const text = `السلام عليكم ورحمة الله،
أنا: ${name || 'أحد الضيوف'}
حالة الحضور لحفل زفاف عادل وسمر (الجمعة 23/10/2026 - 8:30 م): ${attending ? 'سأحضر بكل سرور إن شاء الله' : 'أعتذر بكل حب لظروف خاصة'}
عدد الأفراد: ${companions}
التهنئة: ${message || 'ألف مبروك وبالرفاء والبنين'}`;

    const url = `https://wa.me/${WEDDING_DATA.contact.whatsappNumber}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <section id="rsvp" className="py-14 sm:py-20 px-4 bg-[#F7F3EB]/60 border-t border-[#E8DFC8]/60 relative">
      <div className="max-w-4xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <p className="text-xs uppercase tracking-widest text-[#996515] font-serif font-medium mb-2">
            RSVP & Guestbook · تأكيد الحضور ودفتر التهاني
          </p>
          <h2 className="text-3xl sm:text-4xl font-amiri font-bold text-[#1A1816]">
            شاركنا فرحتنا بحضورك ودعواتك
          </h2>
          <GoldFlourishDivider />
          <p className="text-sm text-[#766E65] font-alexandria mt-2">
            يسعدنا تأكيد حضوركم لمساعدتنا في الترحيب بكم بأفضل شكل ممكن
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left/Form Column (7 cols) */}
          <div className="lg:col-span-7 bg-white border border-[#E8DFC8] rounded-3xl p-6 sm:p-8 shadow-md relative">
            {isSubmitted ? (
              <div className="text-center py-10 space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 mb-2">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-amiri font-bold text-[#1A1816]">
                  شكراً لك يا {name}!
                </h3>
                <p className="text-sm text-[#5B544D] max-w-md mx-auto leading-relaxed">
                  {attending
                    ? 'تسلم وتسعدنا رؤيتك يوم الجمعة 23 أكتوبر 2026 في قاعة الروضة بمسجد المشير طنطاوي الساعة 8:30 مساءً. فرحتنا تكتمل بوجودك!'
                    : 'نشكرك على مشاعرك الصادقة ودعواتك الطيبة، ونتمنى أن نلتقي بك في مناسبات سعيدة قادمة.'}
                </p>

                <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={handleSendViaWhatsApp}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-full bg-[#25D366] text-white text-xs sm:text-sm font-medium hover:bg-[#20ba59] transition-colors flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>إرسال التأكيد أيضاً عبر واتساب</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsSubmitted(false);
                      setName('');
                      setMessage('');
                    }}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-full border border-[#E8DFC8] text-xs text-[#766E65] hover:text-[#2C2723] hover:border-[#996515] transition-colors"
                  >
                    تسجيل رد آخر
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Attendance Toggle */}
                <div>
                  <label className="block text-xs font-semibold text-[#766E65] uppercase tracking-wider mb-2 font-serif">
                    حالة الحضور
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setAttending(true)}
                      className={`p-3 rounded-xl border text-xs sm:text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                        attending
                          ? 'bg-[#1A1816] text-[#FAF8F5] border-[#1A1816] shadow-xs'
                          : 'bg-[#FAF8F5] text-[#766E65] border-[#E8DFC8] hover:border-[#C5A059]'
                      }`}
                    >
                      <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                      <span>سأحضر بكل سرور</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setAttending(false)}
                      className={`p-3 rounded-xl border text-xs sm:text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                        !attending
                          ? 'bg-[#1A1816] text-[#FAF8F5] border-[#1A1816] shadow-xs'
                          : 'bg-[#FAF8F5] text-[#766E65] border-[#E8DFC8] hover:border-[#C5A059]'
                      }`}
                    >
                      <Heart className="w-4 h-4 text-[#D4AF37]" />
                      <span>أعتذر بكل حب</span>
                    </button>
                  </div>
                </div>

                {/* Name Input */}
                <div>
                  <label htmlFor="guest-name" className="block text-xs font-semibold text-[#766E65] uppercase tracking-wider mb-1.5 font-serif">
                    الاسم الكريم <span className="text-[#996515]">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-[#C5A059] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="guest-name"
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="اكتب اسمك الثلاثي أو اللقب"
                      className="w-full pr-10 pl-4 py-2.5 bg-[#FAF8F5] border border-[#E8DFC8] rounded-xl text-sm text-[#1A1816] placeholder:text-[#A39A8E] focus:outline-hidden focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-all"
                    />
                  </div>
                </div>

                {/* Companions Count (only if attending) */}
                {attending && (
                  <div>
                    <label htmlFor="companions-count" className="block text-xs font-semibold text-[#766E65] uppercase tracking-wider mb-1.5 font-serif">
                      إجمالي عدد الأفراد (شاملاً حضرتك)
                    </label>
                    <div className="relative">
                      <Users className="w-4 h-4 text-[#C5A059] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <select
                        id="companions-count"
                        value={companions}
                        onChange={(e) => setCompanions(Number(e.target.value))}
                        className="w-full pr-10 pl-4 py-2.5 bg-[#FAF8F5] border border-[#E8DFC8] rounded-xl text-sm text-[#1A1816] focus:outline-hidden focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-all"
                      >
                        <option value={1}>فرد واحد (أنا فقط)</option>
                        <option value={2}>فردان (شخصان)</option>
                        <option value={3}>3 أفراد</option>
                        <option value={4}>4 أفراد</option>
                        <option value={5}>عائلة (5+ أفراد)</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* Relationship / Title (Optional) */}
                <div>
                  <label htmlFor="relation-tag" className="block text-xs font-semibold text-[#766E65] uppercase tracking-wider mb-1.5 font-serif">
                    صلة القرابة أو المعرفة (اختياري)
                  </label>
                  <input
                    id="relation-tag"
                    type="text"
                    value={relation}
                    onChange={(e) => setRelation(e.target.value)}
                    placeholder="مثال: صديق العريس / الأهل / زملاء العمل"
                    className="w-full px-4 py-2.5 bg-[#FAF8F5] border border-[#E8DFC8] rounded-xl text-sm text-[#1A1816] placeholder:text-[#A39A8E] focus:outline-hidden focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-all"
                  />
                </div>

                {/* Congratulations / Prayer Message */}
                <div>
                  <label htmlFor="blessing-message" className="block text-xs font-semibold text-[#766E65] uppercase tracking-wider mb-1.5 font-serif">
                    كلمة أو دعوة طيبة للعروسين عادل وسمر
                  </label>
                  <textarea
                    id="blessing-message"
                    rows={3}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="بارك الله لكما وبارك عليكما وجمع بينكما في خير..."
                    className="w-full px-4 py-2.5 bg-[#FAF8F5] border border-[#E8DFC8] rounded-xl text-sm text-[#1A1816] placeholder:text-[#A39A8E] focus:outline-hidden focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-all resize-none"
                  />
                </div>

                {/* Submit Buttons */}
                <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                  <button
                    type="submit"
                    className="w-full flex-1 py-3.5 rounded-full bg-[#1A1816] text-[#FAF8F5] text-sm font-medium hover:bg-[#996515] transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer active:scale-98"
                  >
                    <Send className="w-4 h-4 text-[#E8C15A]" />
                    <span>تأكيد الرد وإرسال التهنئة</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSendViaWhatsApp}
                    className="w-full sm:w-auto px-5 py-3.5 rounded-full bg-[#25D366] text-white text-sm font-medium hover:bg-[#20ba59] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                    title="تأكيد مباشر عبر واتساب"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>تأكيد عبر واتساب</span>
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Right/Guestbook Column (5 cols) */}
          <div className="lg:col-span-5 bg-white border border-[#E8DFC8] rounded-3xl p-6 shadow-md flex flex-col h-full max-h-[550px]">
            <div className="flex items-center justify-between pb-4 border-b border-[#F0E8D8] mb-4">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#996515]" />
                <h3 className="text-base font-serif font-bold text-[#1A1816]">
                  دفتر تهاني الأحبة
                </h3>
              </div>
              <span className="text-xs text-[#766E65] font-mono">
                {blessings.length} تهنئة
              </span>
            </div>

            <div className="overflow-y-auto space-y-3.5 pr-1 flex-1 text-right">
              {blessings.map((b) => (
                <div
                  key={b.id}
                  className="bg-[#FAF8F5] border border-[#F0E8D8] rounded-2xl p-4 text-xs space-y-1.5 hover:border-[#D4AF37]/50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#1A1816] text-sm">
                      {b.name}
                    </span>
                    <span className="text-[10px] text-[#A39A8E]">
                      {b.createdAt}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-[11px] text-[#996515]">
                    <span>{b.relation || 'محب'}</span>
                    {b.attending && (
                      <>
                        <span>·</span>
                        <span className="text-emerald-700 font-medium">سيكون حاضراً بإذن الله</span>
                      </>
                    )}
                  </div>

                  <p className="text-[#3C3630] font-amiri text-sm leading-relaxed pt-1">
                    &ldquo;{b.message}&rdquo;
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
