import React, { useState } from 'react';
import { Sparkles, Calendar, MapPin, Share2, Check, ArrowDown } from 'lucide-react';
import { GoldCrest, GoldFlourishDivider, CornerFlourish } from './Ornaments';
import { weddingAudio } from '../utils/audio';

interface HeroEnvelopeProps {
  onScrollToDetails: () => void;
  onScrollToRsvp: () => void;
}

export const HeroEnvelope: React.FC<HeroEnvelopeProps> = ({
  onScrollToDetails,
  onScrollToRsvp,
}) => {
  const [isOpen, setIsOpen] = useState(true); // Open by default for zero-latency, but can toggle or view folded envelope
  const [isCopied, setIsCopied] = useState(false);

  const handleOpenEnvelope = () => {
    setIsOpen(true);
    weddingAudio.init();
    if (!weddingAudio.getStatus()) {
      weddingAudio.play();
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: 'دعوة زفاف عادل وسمر | 23 أكتوبر 2026',
      text: 'نتشرف بدعوتكم لحضور حفل زفاف وعقد قران عادل وسمر يوم الجمعة 23 أكتوبر 2026 في مسجد المشير طنطاوي - قاعة الروضة الساعة 8:30 مساءً.',
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        // User cancelled or unsupported
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    }
  };

  return (
    <section id="top" className="relative min-h-[92vh] flex flex-col items-center justify-center pt-8 pb-16 px-4 overflow-hidden">
      {/* Subtle luxury ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-gradient-to-tr from-[#D4AF37]/10 via-[#F3E5AB]/15 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-[#C5A059]/5 rounded-full blur-2xl pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-2xl mx-auto relative z-10">
        {!isOpen ? (
          /* Folded Luxury Envelope View */
          <div className="relative bg-[#F9F5EC] border-2 border-[#D4AF37]/40 rounded-2xl p-8 sm:p-12 shadow-2xl text-center max-w-lg mx-auto transform transition-all duration-500 hover:scale-[1.01]">
            <CornerFlourish position="top-left" className="absolute top-3 left-3" />
            <CornerFlourish position="top-right" className="absolute top-3 right-3" />
            <CornerFlourish position="bottom-left" className="absolute bottom-3 left-3" />
            <CornerFlourish position="bottom-right" className="absolute bottom-3 right-3" />

            <div className="my-6">
              <GoldCrest size={100} className="mx-auto" />
            </div>

            <p className="text-xs uppercase tracking-widest text-[#996515] font-serif mb-2">
              Wedding Invitation · بطاقة دعوة زفاف
            </p>
            <h1 className="text-3xl sm:text-4xl font-serif font-bold text-[#1A1816] mb-3">
              Adel & Samar
            </h1>
            <p className="font-amiri text-xl text-[#766E65] mb-6">
              عادل و سمر
            </p>

            {/* Wax Seal Button */}
            <div className="my-6">
              <button
                type="button"
                onClick={handleOpenEnvelope}
                className="group relative inline-flex items-center justify-center"
              >
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#996515] via-[#D4AF37] to-[#8B6508] p-1 shadow-lg group-hover:scale-105 transition-transform duration-300 flex items-center justify-center">
                  <div className="w-full h-full rounded-full border border-[#FFF8E7]/50 flex flex-col items-center justify-center text-[#FAF8F5]">
                    <Sparkles className="w-4 h-4 mb-0.5 text-[#FFF8E7]" />
                    <span className="text-[11px] font-semibold tracking-wider font-serif">افتح</span>
                  </div>
                </div>
              </button>
              <p className="text-xs text-[#766E65] mt-3">انقر على الختم الملكي لفتح الدعوة</p>
            </div>
          </div>
        ) : (
          /* Opened Luxury Stationery Invitation Card */
          <div className="relative bg-white border border-[#E8DFC8] rounded-3xl p-6 sm:p-10 md:p-12 shadow-xl paper-card transition-all duration-700">
            {/* Elegant Corner Filigree */}
            <CornerFlourish position="top-left" className="absolute top-3 left-3 sm:top-5 sm:left-5" />
            <CornerFlourish position="top-right" className="absolute top-3 right-3 sm:top-5 sm:right-5" />
            <CornerFlourish position="bottom-left" className="absolute bottom-3 left-3 sm:bottom-5 sm:left-5" />
            <CornerFlourish position="bottom-right" className="absolute bottom-3 right-3 sm:bottom-5 sm:right-5" />

            {/* Header Verse */}
            <div className="text-center pt-2 sm:pt-4">
              <p className="font-amiri text-sm sm:text-base text-[#996515] tracking-wide mb-1">
                بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
              </p>
              <p className="font-amiri text-xs sm:text-sm text-[#766E65] max-w-md mx-auto leading-relaxed italic px-4">
                &ldquo;وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً&rdquo;
              </p>
            </div>

            {/* Monogram Crest */}
            <div className="my-5 sm:my-6 flex justify-center">
              <GoldCrest size={110} className="drop-shadow-xs" />
            </div>

            {/* Couple Names Section */}
            <div className="text-center space-y-2">
              <p className="text-xs uppercase tracking-widest text-[#B38F3F] font-serif font-medium">
                Wedding Ceremony · حفل زفاف وعقد قران
              </p>

              {/* English Script & Serif Names */}
              <div className="py-1">
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-script text-gold-gradient tracking-wide leading-tight">
                  Adel & Samar
                </h1>
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-amiri font-bold text-[#1A1816] mt-2">
                  عادل و سمر
                </h2>
              </div>

              <GoldFlourishDivider />

              {/* Event Quick Snapshot */}
              <div className="pt-2 pb-4 flex flex-wrap items-center justify-center gap-3 sm:gap-5 text-xs sm:text-sm text-[#5B544D]">
                <div className="flex items-center gap-1.5 bg-[#FAF5E8] px-3.5 py-1 rounded-full border border-[#E8DFC8]">
                  <Calendar className="w-4 h-4 text-[#996515]" />
                  <span className="font-semibold text-[#1A1816]">الجمعة، 23 أكتوبر 2026</span>
                  <span className="text-[#996515] font-mono text-[11px]">(23/10/2026)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[#766E65]">الساعة:</span>
                  <span className="font-semibold text-[#1A1816]">8:30 مساءً</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#C5A059]" />
                  <span className="font-medium text-[#2C2723]">مسجد المشير طنطاوي</span>
                  <span>·</span>
                  <span className="text-[#996515] font-semibold">قاعة الروضة</span>
                </div>
              </div>
            </div>

            {/* Main Interactive Call-to-Actions */}
            <div className="mt-6 pt-4 border-t border-[#F0E8D8] flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                type="button"
                onClick={onScrollToRsvp}
                className="w-full sm:w-auto px-6 py-3 rounded-full bg-[#1A1816] text-[#FAF8F5] text-sm font-medium hover:bg-[#996515] transition-all flex items-center justify-center gap-2 shadow-md active:scale-98"
              >
                <Sparkles className="w-4 h-4 text-[#E8C15A]" />
                <span>تأكيد الحضور (RSVP)</span>
              </button>

              <button
                type="button"
                onClick={onScrollToDetails}
                className="w-full sm:w-auto px-5 py-3 rounded-full border border-[#D4AF37]/50 bg-[#FDFBF7] text-[#2C2723] text-sm font-medium hover:bg-[#FAF8F5] hover:border-[#996515] transition-all flex items-center justify-center gap-2"
              >
                <span>تفاصيل الحفل والموقع</span>
                <ArrowDown className="w-4 h-4 text-[#996515]" />
              </button>

              <button
                type="button"
                onClick={handleShare}
                className="w-full sm:w-auto px-4 py-3 rounded-full border border-[#E8DFC8] bg-white text-[#766E65] text-sm font-medium hover:text-[#2C2723] hover:border-[#C5A059] transition-all flex items-center justify-center gap-2"
                title="مشاركة رابط الدعوة"
              >
                {isCopied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span className="text-emerald-700 text-xs">تم نسخ الرابط!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4 text-[#C5A059]" />
                    <span className="text-xs">مشاركة الدعوة</span>
                  </>
                )}
              </button>
            </div>

            {/* Fold Envelope option for novelty */}
            <div className="mt-4 text-center">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-[11px] text-[#A39A8E] hover:text-[#766E65] transition-colors underline decoration-dotted"
              >
                طي الظرف الملكي
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Subtle Scroll Down Indicator */}
      <div className="mt-8 flex flex-col items-center gap-1 text-[#996515]/70 animate-bounce cursor-pointer" onClick={onScrollToDetails}>
        <span className="text-xs font-serif font-medium">تفاصيل المناسبة</span>
        <ArrowDown className="w-4 h-4" />
      </div>
    </section>
  );
};
