import React from 'react';
import { Heart, ArrowUp, Phone, MapPin } from 'lucide-react';
import { GoldCrest, GoldFlourishDivider } from './Ornaments';
import { WEDDING_DATA } from '../types/wedding';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#1A1816] text-[#FAF8F5] pt-16 pb-24 sm:pb-16 px-4 relative overflow-hidden">
      {/* Decorative top gold line */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent" />

      <div className="max-w-4xl mx-auto text-center">
        {/* Monogram Crest */}
        <div className="mb-6 flex justify-center opacity-90">
          <GoldCrest size={80} />
        </div>

        {/* Couple Names */}
        <h2 className="text-3xl sm:text-4xl font-script text-gold-gradient tracking-wide mb-1">
          Adel & Samar
        </h2>
        <p className="font-amiri text-xl sm:text-2xl text-[#E8C15A] mb-4">
          عادل و سمر
        </p>

        <GoldFlourishDivider className="opacity-40" />

        {/* Heartfelt Note */}
        <p className="font-amiri text-base sm:text-lg text-[#D6CEBE] max-w-md mx-auto leading-relaxed my-4">
          &ldquo;بكم تكتمل فرحتنا وتزداد ليلتنا نوراً وسروراً.. دمتم لنا أهلاً وأحباباً ورفقة خير.&rdquo;
        </p>

        {/* Quick Reference Snapshot */}
        <div className="my-6 inline-flex flex-wrap items-center justify-center gap-3 sm:gap-4 text-xs text-[#A39A8E] border border-white/10 rounded-full px-5 py-2.5 bg-white/5">
          <span className="text-[#E8C15A] font-medium">الجمعة، 23 أكتوبر 2026 (23/10/2026)</span>
          <span>·</span>
          <span>الساعة 8:30 مساءً</span>
          <span>·</span>
          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>مسجد المشير طنطاوي · قاعة الروضة</span>
          </div>
          <span>·</span>
          <div className="flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
            <a href={`tel:${WEDDING_DATA.contact.phone}`} className="hover:text-white transition-colors" dir="ltr">
              {WEDDING_DATA.contact.displayPhone}
            </a>
          </div>
        </div>

        {/* Back to top button */}
        <div className="mt-6 mb-8">
          <button
            type="button"
            onClick={scrollToTop}
            className="inline-flex items-center gap-2 text-xs font-serif text-[#C5A059] hover:text-white transition-colors p-2 cursor-pointer"
          >
            <ArrowUp className="w-4 h-4" />
            <span>العودة إلى الأعلى</span>
          </button>
        </div>

        {/* Minimal Copyright */}
        <div className="pt-6 border-t border-white/10 text-[11px] text-[#766E65] flex items-center justify-center gap-1.5 font-serif">
          <span>حفل زفاف عادل وسمر</span>
          <span>·</span>
          <span>Adel & Samar Wedding Invitation</span>
          <Heart className="w-3 h-3 text-[#C5A059] fill-[#C5A059]" />
        </div>
      </div>
    </footer>
  );
};
