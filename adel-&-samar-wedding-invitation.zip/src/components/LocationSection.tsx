import React, { useState } from 'react';
import { MapPin, Navigation, Copy, Check, ExternalLink, Car } from 'lucide-react';
import { GoldFlourishDivider } from './Ornaments';
import { WEDDING_DATA } from '../types/wedding';

export const LocationSection: React.FC = () => {
  const [copied, setCopied] = useState(false);

  // Exact Google Maps Search Link using the provided query
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    WEDDING_DATA.venue.googleMapsQuery
  )}`;

  // Waze navigation url
  const wazeUrl = `https://waze.com/ul?q=${encodeURIComponent('مسجد المشير طنطاوي قاعة الروضة')}`;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(WEDDING_DATA.venue.googleMapsQuery);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="location" className="py-14 sm:py-20 px-4 bg-[#FAF8F5] relative">
      <div className="max-w-5xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <p className="text-xs uppercase tracking-widest text-[#996515] font-serif font-medium mb-2">
            Location & Directions · موقع الحفل والاتجاهات
          </p>
          <h2 className="text-3xl sm:text-4xl font-amiri font-bold text-[#1A1816]">
            مسجد المشير طنطاوي – قاعة الروضة
          </h2>
          <GoldFlourishDivider />
          <p className="text-sm text-[#766E65] font-alexandria mt-2">
            اضغط على الزر أدناه لفتح الموقع فوراً في تطبيق خرائط Google والحصول على أدق مسار
          </p>
        </div>

        {/* Location Showcase Card */}
        <div className="bg-white border border-[#E8DFC8] rounded-3xl overflow-hidden shadow-md">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left/Main Column: Address, Actions & Tips (7 cols) */}
            <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-between">
              <div>
                <div className="inline-flex items-center gap-2 text-xs font-serif text-[#996515] bg-[#FAF5E8] px-3 py-1.5 rounded-full border border-[#E8DFC8] mb-4">
                  <MapPin className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>محور المشير طنطاوي · التجمع / مدينة نصر</span>
                </div>

                <h3 className="text-2xl font-amiri font-bold text-[#1A1816] mb-2">
                  مسجد المشير طنطاوي
                </h3>
                <h4 className="text-lg font-amiri font-semibold text-[#996515] mb-4">
                  قاعة الروضة للمناسبات
                </h4>

                <div className="bg-[#FAF8F5] border border-[#F0E8D8] rounded-2xl p-4 mb-6">
                  <p className="text-xs text-[#766E65] uppercase tracking-wider mb-1 font-serif">
                    العنوان الكامل:
                  </p>
                  <p className="text-sm text-[#2C2723] font-medium leading-relaxed">
                    {WEDDING_DATA.venue.addressAr}
                  </p>
                  <p className="text-xs text-[#766E65] font-serif mt-1">
                    {WEDDING_DATA.venue.addressEn}
                  </p>
                  <div className="mt-2 pt-2 border-t border-[#E8DFC8]/60 flex items-center justify-between">
                    <span className="text-xs font-mono text-[#996515]">
                      Plus Code: 298M+X89
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyAddress}
                      className="text-xs text-[#996515] hover:text-[#1A1816] flex items-center gap-1 font-medium transition-colors cursor-pointer"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-700">تم النسخ</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>نسخ العنوان</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Driving & Arrival Tips */}
                <div className="space-y-3 mb-6">
                  <div className="flex items-start gap-3 text-xs text-[#5B544D]">
                    <Car className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                    <span>
                      <strong className="text-[#2C2723]">مواقف السيارات:</strong> يتوفر ساحات انتظار رحبة ومجانية أمام المسجد وقاعة الروضة مباشرة لسهولة صف السيارات.
                    </span>
                  </div>
                  <div className="flex items-start gap-3 text-xs text-[#5B544D]">
                    <Navigation className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                    <span>
                      <strong className="text-[#2C2723]">طريق الوصول:</strong> يقع المسجد على محور المشير طنطاوي مباشرة، بالقرب من الطريق الدائري ومحور NA، ويسهل الوصول إليه من التجمع ومدينة نصر والمعادي ومصر الجديدة.
                    </span>
                  </div>
                </div>
              </div>

              {/* Primary Action Buttons */}
              <div className="pt-4 border-t border-[#F0E8D8] flex flex-col sm:flex-row items-center gap-3">
                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto flex-1 px-6 py-3.5 rounded-full bg-[#1A1816] text-[#FAF8F5] text-sm font-medium hover:bg-[#996515] transition-all flex items-center justify-center gap-2 shadow-sm text-center"
                >
                  <Navigation className="w-4 h-4 text-[#E8C15A]" />
                  <span>فتح الموقع في Google Maps</span>
                  <ExternalLink className="w-3.5 h-3.5 opacity-70" />
                </a>

                <a
                  href={wazeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-5 py-3.5 rounded-full border border-[#E8DFC8] bg-white text-[#766E65] text-sm font-medium hover:text-[#2C2723] hover:border-[#C5A059] transition-all flex items-center justify-center gap-2 text-center"
                >
                  <span>Waze</span>
                </a>
              </div>
            </div>

            {/* Right Column: Interactive Map Preview (5 cols) */}
            <div className="lg:col-span-5 bg-[#F4EFE6] relative min-h-[300px] lg:min-h-full border-t lg:border-t-0 lg:border-r border-[#E8DFC8]">
              {/* Google Maps Embed iframe */}
              <iframe
                title="خريطة مسجد المشير طنطاوي"
                width="100%"
                height="100%"
                className="w-full h-full min-h-[320px] lg:min-h-full border-0 grayscale-[20%] contrast-[1.05]"
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://maps.google.com/maps?q=${encodeURIComponent('مسجد المشير طنطاوي El-Mosheer Tantawy Mosque Cairo')}&t=&z=15&ie=UTF8&iwloc=&output=embed`}
              />

              {/* Floating map quick pill */}
              <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-md px-3.5 py-1.5 rounded-full shadow-md border border-[#E8DFC8] flex items-center gap-2 text-xs font-medium text-[#1A1816]">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                <span>قاعة الروضة</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
