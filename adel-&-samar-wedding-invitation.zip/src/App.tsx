/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar';
import { HeroEnvelope } from './components/HeroEnvelope';
import { WelcomeMessage } from './components/WelcomeMessage';
import { EventDetails } from './components/EventDetails';
import { LocationSection } from './components/LocationSection';
import { CountdownSection } from './components/CountdownSection';
import { ContactSection } from './components/ContactSection';
import { RsvpSection } from './components/RsvpSection';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';

export default function App() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#2C2723] flex flex-col font-alexandria relative selection:bg-[#D4AF37]/20 selection:text-[#1A1816]">
      {/* Top Bar adhering to Top Bar Contract */}
      <Navbar onRsvpClick={() => scrollToSection('rsvp')} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Section 1: Opening Hero Screen with Adel & Samar and interactive envelope */}
        <HeroEnvelope
          onScrollToDetails={() => scrollToSection('details')}
          onScrollToRsvp={() => scrollToSection('rsvp')}
        />

        {/* Section 2: Heartfelt Welcome Message to Guests */}
        <WelcomeMessage />

        {/* Section 3: Event Details (Venue, Hall, Time) */}
        <EventDetails onOpenMap={() => scrollToSection('location')} />

        {/* Section 4: Location & Google Maps */}
        <LocationSection />

        {/* Section 6: Countdown (respecting date constraint with clear placeholder & preview) */}
        <CountdownSection />

        {/* Section 5: Direct Phone Call & WhatsApp Section */}
        <ContactSection />

        {/* Section 7: RSVP Attendance & Live Guestbook */}
        <RsvpSection />
      </main>

      {/* Section 8: Elegant Footer with Adel & Samar */}
      <Footer />

      {/* Mobile Ergonomic Bottom Action Bar */}
      <FloatingActions onRsvpClick={() => scrollToSection('rsvp')} />
    </div>
  );
}
