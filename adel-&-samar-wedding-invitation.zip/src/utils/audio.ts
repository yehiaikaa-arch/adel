// Ambient Luxury Wedding Chimes & Harp Arpeggiator using Web Audio API
class WeddingAudioPlayer {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private timerId: number | null = null;
  private gainNode: GainNode | null = null;
  private noteIndex: number = 0;

  // Gentle romantic arpeggios (Harp & Celesta frequencies in Hz: F major9 / D minor7)
  private readonly melodyNotes = [
    349.23, // F4
    440.0,  // A4
    523.25, // C5
    659.25, // E5
    523.25, // C5
    440.0,  // A4
    392.0,  // G4
    493.88, // B4
    587.33, // D5
    493.88, // B4
    329.63, // E4
    392.0,  // G4
    493.88, // B4
    587.33, // D5
    440.0,  // A4
    523.25  // C5
  ];

  public init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.setValueAtTime(0.12, this.ctx.currentTime);
      this.gainNode.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private playGentlePluck(freq: number, duration: number = 2.4) {
    if (!this.ctx || !this.gainNode) return;

    const now = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const noteGain = this.ctx.createGain();

    // Warm sine + soft triangle for warm harp timbre
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(freq, now);

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(freq * 2, now); // soft sparkle overtone

    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.15, now);
    osc2.connect(subGain);
    subGain.connect(noteGain);

    osc1.connect(noteGain);
    noteGain.connect(this.gainNode);

    // Natural exponential pluck envelope
    noteGain.gain.setValueAtTime(0.001, now);
    noteGain.gain.linearRampToValueAtTime(0.28, now + 0.04);
    noteGain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + duration + 0.1);
    osc2.stop(now + duration + 0.1);
  }

  public toggle(onStateChange?: (playing: boolean) => void) {
    if (this.isPlaying) {
      this.stop();
    } else {
      this.play();
    }
    if (onStateChange) onStateChange(this.isPlaying);
    return this.isPlaying;
  }

  public play() {
    this.init();
    if (this.isPlaying) return;
    this.isPlaying = true;

    const step = () => {
      if (!this.isPlaying) return;
      const freq = this.melodyNotes[this.noteIndex % this.melodyNotes.length];
      this.playGentlePluck(freq);
      this.noteIndex++;
      this.timerId = window.setTimeout(step, 850);
    };

    step();
  }

  public stop() {
    this.isPlaying = false;
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
  }

  public getStatus(): boolean {
    return this.isPlaying;
  }
}

export const weddingAudio = new WeddingAudioPlayer();
