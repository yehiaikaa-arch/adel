export interface GuestBlessing {
  id: string;
  name: string;
  relation?: string;
  message: string;
  createdAt: string;
  attending: boolean;
  companionsCount?: number;
}

export interface WeddingInfo {
  groom: {
    en: string;
    ar: string;
  };
  bride: {
    en: string;
    ar: string;
  };
  date: {
    iso: string; // 2026-10-23
    formatted: string; // 23 / 10 / 2026
    ar: string; // الجمعة، 23 أكتوبر 2026
    en: string; // Friday, October 23, 2026
    dayNameAr: string; // يوم الجمعة
    dayNameEn: string; // Friday
    targetDateTime: string; // 2026-10-23T20:30:00
  };
  time: {
    en: string;
    ar: string;
    value24h: string;
  };
  venue: {
    nameAr: string;
    nameEn: string;
    hallAr: string;
    hallEn: string;
    addressAr: string;
    addressEn: string;
    plusCode: string;
    googleMapsQuery: string;
  };
  contact: {
    phone: string;
    displayPhone: string;
    whatsappNumber: string;
  };
}

export const WEDDING_DATA: WeddingInfo = {
  groom: {
    en: "Adel",
    ar: "عادل",
  },
  bride: {
    en: "Samar",
    ar: "سمر",
  },
  date: {
    iso: "2026-10-23",
    formatted: "23 / 10 / 2026",
    ar: "الجمعة، 23 أكتوبر 2026",
    en: "Friday, October 23, 2026",
    dayNameAr: "يوم الجمعة",
    dayNameEn: "Friday",
    targetDateTime: "2026-10-23T20:30:00",
  },
  time: {
    en: "8:30 PM",
    ar: "8:30 مساءً",
    value24h: "20:30",
  },
  venue: {
    nameAr: "مسجد المشير طنطاوي",
    nameEn: "El-Mosheer Tantawy Mosque",
    hallAr: "قاعة الروضة",
    hallEn: "Al-Rawda Hall",
    addressAr: "محور المشير طنطاوي، الحي العاشر، مدينة نصر، القاهرة (بالقرب من التجمع الخامس)",
    addressEn: "El-Moshir Tantawy Axis, Al Hay Al Asher, Nasr City, Cairo Governorate 4440510",
    plusCode: "298M+X89 Cairo",
    googleMapsQuery: "298M+X89 El-Mosheer Tantawy Mosque, El-Moshir Tantawy Axis, Al Hay Al Asher, Nasr City, Cairo Governorate 4440510",
  },
  contact: {
    phone: "01205242682",
    displayPhone: "0120 524 2682",
    whatsappNumber: "201205242682",
  },
};
